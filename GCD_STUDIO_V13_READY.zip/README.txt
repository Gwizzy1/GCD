G.C.D STUDIO - MUSIC ENGINE UPDATE

This version replaces the old Stability Audio backend with Eleven Music.

Netlify environment variable required:
ELEVENLABS_API_KEY = your ElevenLabs API key

Keep the key server-side in Netlify environment variables. Never put it in index.html or client-side code.

The Real Music button now sends one request to /api/music and receives the generated MP3 directly. No Stability API or polling is used.

Eleven Music API endpoint: https://api.elevenlabs.io/v1/music
Model: music_v2_5
Test duration in the UI: 60 seconds.

After connecting this repository to Netlify, add ELEVENLABS_API_KEY and redeploy.
