G.C.D Studio V12 — Real Music Engine Fix

WHAT CHANGED
- AI Song now opens the actual Real Music workspace instead of only the text-AI tool.
- Added visible Song Idea + Style fields.
- Added one real Generate Music button.
- Added /api/music and /api/ai redirects to Netlify Functions as a routing fallback.
- Music generation uses Stability Stable Audio 3.0.
- No provider secret is stored in the browser.
- The music test is set to 60 seconds. Stability charges a flat 26 Stability credits per successful Stable Audio 3.0 generation; duration does not reduce that flat charge.

DEPLOY
1. Extract this ZIP.
2. Deploy the extracted project folder to the EXISTING G.C.D Studio Netlify site.
3. Confirm Netlify detects these files: netlify/functions/music.mjs and netlify/functions/ai.mjs.
4. In Netlify environment variables add:
   Key: STABILITY_API_KEY
   Value/Secret: your Stability API key
5. Make sure the variable is available to Functions.
6. Redeploy after adding/changing the variable.

IMPORTANT
- Never paste the Stability key into index.html or chat.
- Netlify site credits and Stability API credits are separate balances.
- Do not generate a song until the function is deployed and the environment variable is set.
