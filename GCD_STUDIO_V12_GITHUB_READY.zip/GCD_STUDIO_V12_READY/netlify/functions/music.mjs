const STABILITY_API = 'https://api.stability.ai/v2beta';

export default async (req) => {
  if (!process.env.STABILITY_API_KEY) {
    return Response.json({ error: 'Music engine is not configured yet. Add STABILITY_API_KEY in Netlify environment variables.' }, { status: 503 });
  }
  try {
    if (req.method === 'POST') {
      const { prompt = '', duration = 120, output_format = 'mp3' } = await req.json();
      if (!prompt.trim()) return Response.json({ error: 'Enter a music idea first.' }, { status: 400 });
      const form = new FormData();
      form.append('prompt', prompt.slice(0, 10000));
      form.append('model', 'stable-audio-3');
      form.append('duration', String(Math.min(Math.max(Number(duration) || 120, 1), 380)));
      form.append('steps', '8');
      form.append('output_format', output_format === 'wav' ? 'wav' : 'mp3');
      const r = await fetch(`${STABILITY_API}/audio/stable-audio/text-to-audio`, {
        method: 'POST',
        headers: { authorization: `Bearer ${process.env.STABILITY_API_KEY}`, accept: 'application/json', 'stability-client-id': 'GCD-Studio' },
        body: form
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) return Response.json({ error: data?.message || data?.errors || 'Music generation request failed.' }, { status: r.status });
      return Response.json({ ok: true, status: 'processing', id: data.id, message: 'Music generation started.' });
    }

    if (req.method === 'GET') {
      const id = new URL(req.url).searchParams.get('id');
      if (!id) return Response.json({ error: 'Missing generation id.' }, { status: 400 });
      const r = await fetch(`${STABILITY_API}/audio/results/${encodeURIComponent(id)}`, {
        headers: { authorization: `Bearer ${process.env.STABILITY_API_KEY}`, accept: 'application/json', 'stability-client-id': 'GCD-Studio' }
      });
      if (r.status === 202) return Response.json({ ok: true, status: 'processing' }, { status: 202 });
      const type = r.headers.get('content-type') || '';
      if (!r.ok) {
        const data = await r.json().catch(() => ({}));
        return Response.json({ error: data?.message || data?.errors || 'Could not retrieve music.' }, { status: r.status });
      }
      if (type.includes('audio/')) {
        const bytes = await r.arrayBuffer();
        return new Response(bytes, { status: 200, headers: { 'Content-Type': type, 'Cache-Control': 'private, max-age=3600' } });
      }
      return Response.json(await r.json());
    }
    return new Response('Method Not Allowed', { status: 405 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: e?.message || 'Music generation failed.' }, { status: 500 });
  }
};

export const config = { path: '/api/music' };
